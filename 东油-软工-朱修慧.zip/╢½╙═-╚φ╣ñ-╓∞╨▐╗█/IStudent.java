package day13.add.delete.update.select;

import java.util.List;

public interface IStudent {
    List<Student> selectAll();
}
