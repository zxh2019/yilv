package day15.mybatis;

import java.util.List;

/**
 * @author 朱修慧
 * @since 2019-08-08
 *
 */
public interface RoleMapper {
    /**
     * 查找所有的Role信息
     * @return
     */
    List<Role> findAllRole();

    /**
     * 根据id查找信息
     * @return
     */
    Role findRoleById(int id);

    /**
     * 向表中添加数据
     * @param role
     * @return
     */
    int insertRole(Role role);

    /**
     * 修改数据表
     * @param role
     * @return
     */
    int updateRole(Role role);

    /**
     * 删除表中一条数据
     * @param id
     * @return
     */
    int deleteRole(int id);
}
