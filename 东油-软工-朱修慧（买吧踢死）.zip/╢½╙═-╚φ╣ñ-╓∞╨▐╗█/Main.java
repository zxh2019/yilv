package day15.mybatis;

import org.apache.ibatis.session.SqlSession;
import org.apache.log4j.Logger;

import java.util.List;


public class Main {
    private static final Logger LOGGER = Logger.getLogger(Main.class);
    public static void main(String[] args) {
        SqlSession sqlSession=null;
        try{
            sqlSession = SqlSessionFactoryUtil.getSqlSession();
            RoleMapper roleMapper = sqlSession.getMapper(RoleMapper.class);
//            List<Role> list = roleMapper.findAllRole();
//            Role role = roleMapper.findRoleById(2);
//            LOGGER.info(list);
//            Role role = new Role();
//            role.setRoleName("百里屠苏");
//            role.setNote("没我好看");
//            Role role = new Role();
//            role.setId(7);
//            role.setRoleName("杀阡陌");
//            role.setNote("没我好看");
            int x = roleMapper.deleteRole(7);
            sqlSession.commit();
            LOGGER.info(x);
        }catch (Exception e){
          e.printStackTrace();
        }finally {
            if( null != sqlSession){
                sqlSession.close();
            }
        }

    }
}
