package day13.add.delete.update.select;

/**
 * @author 朱修慧
 * @since 2019-08-06
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StudentOperater implements InteStudent {
    static Connection connection = ConnectionClz.getIntense().getConnectionClz();
    static PreparedStatement preparedStatement = null;
    static ResultSet rs = null;
    static List<Student> list = new ArrayList<>();

    // 按照模糊名字查询
    @Override
    public void findByUserNameLike(String userName) {
        String sql = "select * from student where sname like ?";
        try {
            // 在sql语句执行之前，先准备好
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setObject(1, "%" + userName + "%");
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Student student = new Student();
                student.setsNo(rs.getString(1));
                student.setsName(rs.getString(2));
                student.setsSex(rs.getString(3));
                student.setClz(rs.getString(4));
                System.out.println(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeAll(rs);
            closeAll(preparedStatement);
            closeAll(connection);
        }
    }

    // 根据sno字段进行降序操作
    @Override
    public void findOrderByUserName() {
        String sql = "select * from student order by sno desc";
        try {
            preparedStatement = connection.prepareStatement(sql);
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Student student = new Student();
                student.setsNo(rs.getString(1));
                student.setsName(rs.getString(2));
                student.setsSex(rs.getString(3));
                student.setClz(rs.getString(4));
                System.out.println(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeAll(rs);
            closeAll(preparedStatement);
            closeAll(connection);
        }

    }

    // 先根据模糊查询，然后升序排序，最后分页，输出前两页
    @Override
    public List<Student> findByUserNameLikeOrderLimit(String userName, int currPage, int pageSize) {
        String sql = "select * from student where sname like ? ORDER BY sno limit ?,?";
        try {
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setObject(1, userName + "%");
            // 第二个占位符，应该表示的是当前页从什么位置输出，就等于当前页 - 1 * 页的尺寸
            preparedStatement.setObject(2, (currPage - 1) * pageSize);
            preparedStatement.setObject(3, pageSize);
            rs = preparedStatement.executeQuery();
            while (rs.next()) {
                Student student = new Student();
                student.setsNo(rs.getString(1));
                student.setsName(rs.getString(2));
                student.setsSex(rs.getString(3));
                student.setClz(rs.getString(4));
                list.add(student);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            closeAll(rs);
            closeAll(preparedStatement);
            closeAll(connection);
        }
        return list;
    }

    // 关闭连接方法
    public static void closeAll(AutoCloseable ac) {
        if (null != ac) {
            try {
                ac.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
