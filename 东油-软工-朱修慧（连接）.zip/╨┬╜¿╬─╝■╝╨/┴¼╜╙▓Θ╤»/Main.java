package day13.add.delete.update.select;

/**
 * @author 朱修慧
 * @since 2019-08-06
 */
import java.util.List;

public class Main {
    public static void main(String[] args) {
        InteStudent inteStudent=new StudentOperater();
     inteStudent.findByUserNameLike("x");
//        inteStudent.findOrderByUserName();
//        List<Student> list = inteStudent.findByUserNameLikeOrderLimit("x",2,2);
//        list.forEach(System.out::println);
    }
}
