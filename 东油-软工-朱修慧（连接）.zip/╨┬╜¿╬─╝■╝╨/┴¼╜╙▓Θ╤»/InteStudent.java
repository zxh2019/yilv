package day13.add.delete.update.select;

import java.util.List;

/**
 * @author 朱修慧
 * @since 2019-08-06
 */
public interface InteStudent {
    /**
     * 根据名称字段进行模糊查找
     * @param userName
     * @return
     */
      void findByUserNameLike(String userName);

    /**
     * 根据sno字段进行降序操作
     * @return
     */
    void findOrderByUserName();

    /**
     * 完成根据某个字段模糊查找并排序（升序），
     * 然后分页获取第二页数据的操作（每页显示2条）
     * @param userName
     * @param currPage
     * @param pageSize
     * @return
     */
    List<Student> findByUserNameLikeOrderLimit(String userName,int currPage, int pageSize);

}
