package day13.transaction;

import day13.add.delete.update.select.ConnectionClz;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        Connection connection = ConnectionClz.getIntense().getConnectionClz();

        connection.setAutoCommit(false);

        String sql = "insert into gorder values(null,1,100)";

        PreparedStatement  preparedStatement = connection.prepareStatement(sql);
        preparedStatement.executeUpdate();

        String sql1 = "update sto set gcount = gcount - 100 where gid = 1";
        preparedStatement = connection.prepareStatement(sql1);
        preparedStatement.executeUpdate();

        connection.commit();

        preparedStatement.close();
        connection.close();
    }
}
